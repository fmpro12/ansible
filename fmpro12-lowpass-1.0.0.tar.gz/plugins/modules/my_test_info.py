#!/usr/bin/python
import bcrypt
from ansible.module_utils.common.text.converters import to_text
class FilterModule(object):
    def filters(self):
       return {'unique_folders': self.unique_base_paths}
    def unique_base_paths(self, password):
       hashed_txt = to_text(password)
       hashed = bcrypt.hashpw(hashed_txt.encode('utf8'), bcrypt.gensalt())
       hashed = hashed.decode('utf-8').replace('$2b', '$2y')
       return hashed
