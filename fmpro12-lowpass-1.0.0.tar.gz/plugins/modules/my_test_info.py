#!/usr/bin/python
class FilterModule(object):
    def filters(self):
        return {'unique_folders': self.unique_base_paths}

    def unique_base_paths(self, password):
        return password.lower()

